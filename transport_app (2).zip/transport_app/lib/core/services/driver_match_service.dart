import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';

class DriverMatchService {
  final FirebaseFirestore db = FirebaseFirestore.instance;

  //////////////////////////////////////////////////////
  /// Find Nearest Available Driver
  //////////////////////////////////////////////////////

  Future<String?> findNearestDriver(double lat, double lng) async {
    var drivers = await db
        .collection("drivers")
        .where("available", isEqualTo: true)
        .get();

    double minDistance = 999999;
    String? nearestDriver;

    for (var d in drivers.docs) {
      double dLat = d["lat"];
      double dLng = d["lng"];

      double distance = Geolocator.distanceBetween(lat, lng, dLat, dLng);

      if (distance < minDistance) {
        minDistance = distance;
        nearestDriver = d.id;
      }
    }

    return nearestDriver;
  }

  //////////////////////////////////////////////////////
  /// Set Driver Availability
  //////////////////////////////////////////////////////

  Future<void> setAvailability(String driverId, bool available) async {
    await db.collection("drivers").doc(driverId).update({
      "available": available,
    });
  }
}
