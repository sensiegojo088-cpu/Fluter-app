import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class LocationService {
  final FirebaseFirestore db = FirebaseFirestore.instance;

  //////////////////////////////////////////////////////
  /// Get Current Position
  //////////////////////////////////////////////////////

  Future<Position?> getCurrentPosition() async {
    bool enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) return null;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.deniedForever) return null;

    return await Geolocator.getCurrentPosition();
  }

  //////////////////////////////////////////////////////
  /// Update Driver Location in Firestore
  //////////////////////////////////////////////////////

  Future<void> updateDriverLocation(String driverId) async {
    Position? pos = await getCurrentPosition();
    if (pos == null) return;

    await db.collection("drivers").doc(driverId).update({
      "lat": pos.latitude,
      "lng": pos.longitude,
      "updatedAt": FieldValue.serverTimestamp(),
    });
  }

  //////////////////////////////////////////////////////
  /// Stream Position
  //////////////////////////////////////////////////////

  Stream<Position> streamPosition() {
    return Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 10,
      ),
    );
  }
}
