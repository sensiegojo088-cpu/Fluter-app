import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/trip_model.dart';
import '../../models/rating_model.dart';

class FirebaseService {
  final FirebaseFirestore db = FirebaseFirestore.instance;

  //////////////////////////////////////////////////////
  /// Create Trip
  //////////////////////////////////////////////////////

  Future<String> createTrip(Trip trip) async {
    DocumentReference ref = await db.collection("trips").add({
      "distance": trip.distance,
      "duration": trip.duration,
      "price": trip.price,
      "pickup": trip.pickup,
      "destination": trip.destination,
      "status": "searching",
      "createdAt": FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  //////////////////////////////////////////////////////
  /// Accept Trip
  //////////////////////////////////////////////////////

  Future<void> acceptTrip(String tripId, String driverId) async {
    await db.collection("trips").doc(tripId).update({
      "driverId": driverId,
      "status": "driver_assigned",
    });
  }

  //////////////////////////////////////////////////////
  /// Update Trip Status
  //////////////////////////////////////////////////////

  Future<void> updateStatus(String tripId, String status) async {
    await db.collection("trips").doc(tripId).update({
      "status": status,
      "updatedAt": FieldValue.serverTimestamp(),
    });
  }

  //////////////////////////////////////////////////////
  /// Complete Trip
  //////////////////////////////////////////////////////

  Future<void> completeTrip(String tripId) async {
    await updateStatus(tripId, "completed");
  }

  //////////////////////////////////////////////////////
  /// Add Rating
  //////////////////////////////////////////////////////

  Future<void> addRating(Rating rating) async {
    await db.collection("ratings").add({
      "tripId": rating.tripId,
      "driverId": rating.driverId,
      "stars": rating.stars,
      "comment": rating.comment,
      "createdAt": FieldValue.serverTimestamp(),
    });
  }

  //////////////////////////////////////////////////////
  /// Stream Trip
  //////////////////////////////////////////////////////

  Stream<DocumentSnapshot> streamTrip(String tripId) {
    return db.collection("trips").doc(tripId).snapshots();
  }

  //////////////////////////////////////////////////////
  /// Stream Driver Location
  //////////////////////////////////////////////////////

  Stream<DocumentSnapshot> streamDriver(String driverId) {
    return db.collection("drivers").doc(driverId).snapshots();
  }
}
