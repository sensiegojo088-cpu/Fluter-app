import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String? _verificationId;

  //////////////////////////////////////////////////////
  /// Send OTP
  //////////////////////////////////////////////////////

  Future<void> sendOTP({
    required String phoneNumber,
    required Function(String verificationId) onCodeSent,
    required Function(String error) onError,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: (FirebaseAuthException e) {
        switch (e.code) {
          case 'invalid-phone-number':
            onError("رقم الهاتف غير صحيح");
            break;
          case 'too-many-requests':
            onError("تم تجاوز عدد المحاولات، حاول لاحقاً");
            break;
          case 'network-request-failed':
            onError("تحقق من اتصالك بالإنترنت");
            break;
          default:
            onError(e.message ?? "حدث خطأ غير متوقع");
        }
      },
      codeSent: (String verificationId, int? resendToken) {
        _verificationId = verificationId;
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        _verificationId = verificationId;
      },
    );
  }

  //////////////////////////////////////////////////////
  /// Verify OTP
  //////////////////////////////////////////////////////

  Future<bool> verifyOTP({
    required String verificationId,
    required String otp,
  }) async {
    try {
      PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: verificationId,
        smsCode: otp,
      );
      await _auth.signInWithCredential(credential);
      return true;
    } catch (e) {
      return false;
    }
  }

  //////////////////////////////////////////////////////
  /// Get Current User
  //////////////////////////////////////////////////////

  User? get currentUser => _auth.currentUser;

  //////////////////////////////////////////////////////
  /// Sign Out
  //////////////////////////////////////////////////////

  Future<void> signOut() async {
    await _auth.signOut();
  }
}
