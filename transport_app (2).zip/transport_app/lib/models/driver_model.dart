class Driver {
  final String id;
  final String name;
  final double rating;
  final double lat;
  final double lng;
  final bool available;

  Driver({
    required this.id,
    required this.name,
    required this.rating,
    required this.lat,
    required this.lng,
    required this.available,
  });

  factory Driver.fromMap(Map<String, dynamic> map, String id) {
    return Driver(
      id: id,
      name: map["name"] ?? "",
      rating: (map["rating"] ?? 0.0).toDouble(),
      lat: (map["lat"] ?? 0.0).toDouble(),
      lng: (map["lng"] ?? 0.0).toDouble(),
      available: map["available"] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      "name": name,
      "rating": rating,
      "lat": lat,
      "lng": lng,
      "available": available,
    };
  }
}
