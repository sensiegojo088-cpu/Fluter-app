class Rating {
  final String tripId;
  final String driverId;
  final int stars;
  final String comment;

  Rating({
    required this.tripId,
    required this.driverId,
    required this.stars,
    required this.comment,
  });

  Map<String, dynamic> toMap() {
    return {
      "tripId": tripId,
      "driverId": driverId,
      "stars": stars,
      "comment": comment,
    };
  }
}
