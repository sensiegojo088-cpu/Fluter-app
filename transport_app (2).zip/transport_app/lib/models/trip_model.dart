import 'tier_model.dart';

class Trip {
  final String id;
  final Tier tier;
  final double distance;
  final int duration;
  final double price;
  final String pickup;
  final String destination;
  final String status;

  Trip({
    required this.id,
    required this.tier,
    required this.distance,
    required this.duration,
    required this.price,
    required this.pickup,
    required this.destination,
    required this.status,
  });
}
