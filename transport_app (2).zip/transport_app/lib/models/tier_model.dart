import 'package:flutter/material.dart';

class Tier {
  final String id;
  final String name;
  final Color color;
  final double pricePerKm;
  final String description;
  final String eta;

  const Tier({
    required this.id,
    required this.name,
    required this.color,
    required this.pricePerKm,
    required this.description,
    required this.eta,
  });
}
