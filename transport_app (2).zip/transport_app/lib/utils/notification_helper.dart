import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

class NotificationHelper {
  static final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  //////////////////////////////////////////////////////
  /// Initialize
  //////////////////////////////////////////////////////

  static Future<void> init() async {
    await _messaging.requestPermission();
    String? token = await _messaging.getToken();
    debugPrint("FCM TOKEN: $token");
  }

  //////////////////////////////////////////////////////
  /// Show Snackbar Notification
  //////////////////////////////////////////////////////

  static void showAlert(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  //////////////////////////////////////////////////////
  /// Driver Accepted Notification
  //////////////////////////////////////////////////////

  static void driverAccepted(BuildContext context) {
    showAlert(context, "Driver accepted your trip");
  }

  //////////////////////////////////////////////////////
  /// Approaching Destination Notification
  //////////////////////////////////////////////////////

  static void approachingDestination(BuildContext context) {
    showAlert(context, "تبقى 10 كم للوصول");
  }
}
