import 'package:geolocator/geolocator.dart';

double calculateDistance(
  double startLat,
  double startLng,
  double endLat,
  double endLng,
) {
  double meters = Geolocator.distanceBetween(
    startLat,
    startLng,
    endLat,
    endLng,
  );
  return meters / 1000;
}
