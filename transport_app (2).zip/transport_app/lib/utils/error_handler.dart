import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ErrorHandler {

  //////////////////////////////////////////////////////
  /// Show Error SnackBar
  //////////////////////////////////////////////////////

  static void showError(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.error_outline, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 4),
      ),
    );
  }

  //////////////////////////////////////////////////////
  /// Show Success SnackBar
  //////////////////////////////////////////////////////

  static void showSuccess(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle_outline, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  //////////////////////////////////////////////////////
  /// Handle Firebase Auth Errors
  //////////////////////////////////////////////////////

  static String handleAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-phone-number':
        return "رقم الهاتف غير صحيح";
      case 'too-many-requests':
        return "تم تجاوز عدد المحاولات، حاول لاحقاً";
      case 'invalid-verification-code':
        return "رمز التحقق غير صحيح";
      case 'session-expired':
        return "انتهت صلاحية الرمز، أعد الإرسال";
      case 'network-request-failed':
        return "تحقق من اتصالك بالإنترنت";
      default:
        return e.message ?? "حدث خطأ غير متوقع";
    }
  }

  //////////////////////////////////////////////////////
  /// Handle Firestore Errors
  //////////////////////////////////////////////////////

  static String handleFirestoreError(FirebaseException e) {
    switch (e.code) {
      case 'permission-denied':
        return "ليس لديك صلاحية للوصول";
      case 'unavailable':
        return "الخدمة غير متاحة حالياً، حاول لاحقاً";
      case 'not-found':
        return "البيانات غير موجودة";
      default:
        return "حدث خطأ في الاتصال بالخادم";
    }
  }

  //////////////////////////////////////////////////////
  /// No Internet Dialog
  //////////////////////////////////////////////////////

  static void showNoInternet(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.wifi_off, color: Colors.red),
            SizedBox(width: 10),
            Text("لا يوجد اتصال"),
          ],
        ),
        content: const Text("تحقق من اتصالك بالإنترنت وحاول مجدداً"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("موافق"),
          ),
        ],
      ),
    );
  }

  //////////////////////////////////////////////////////
  /// Loading Dialog
  //////////////////////////////////////////////////////

  static void showLoading(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(),
      ),
    );
  }

  static void hideLoading(BuildContext context) {
    Navigator.pop(context);
  }
}
