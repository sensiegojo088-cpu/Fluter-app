import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

////////////////////////////////////////////////////////
/// Admin Dashboard
////////////////////////////////////////////////////////

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("لوحة التحكم")),
      body: GridView.count(
        crossAxisCount: 2,
        padding: const EdgeInsets.all(16),
        children: [
          _DashboardCard(title: "السائقون", icon: Icons.drive_eta, onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminDrivers()));
          }),
          _DashboardCard(title: "الرحلات", icon: Icons.trip_origin, onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminTrips()));
          }),
          _DashboardCard(title: "الحافلات", icon: Icons.directions_bus, onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminBuses()));
          }),
          _DashboardCard(title: "المستخدمون", icon: Icons.people, onTap: () {}),
        ],
      ),
    );
  }
}

class _DashboardCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;

  const _DashboardCard({required this.title, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8),
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 48),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

////////////////////////////////////////////////////////
/// Admin Drivers
////////////////////////////////////////////////////////

class AdminDrivers extends StatelessWidget {
  const AdminDrivers({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("إدارة السائقين")),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection("drivers").snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          var docs = snapshot.data!.docs;
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              var d = docs[index].data() as Map<String, dynamic>;
              return ListTile(
                leading: const Icon(Icons.person),
                title: Text(d["name"] ?? "سائق"),
                subtitle: Text("تقييم: ${d["rating"] ?? 0}"),
                trailing: Icon(
                  Icons.circle,
                  color: (d["available"] == true) ? Colors.green : Colors.grey,
                  size: 14,
                ),
              );
            },
          );
        },
      ),
    );
  }
}

////////////////////////////////////////////////////////
/// Admin Trips
////////////////////////////////////////////////////////

class AdminTrips extends StatelessWidget {
  const AdminTrips({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("إدارة الرحلات")),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection("trips").snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          var docs = snapshot.data!.docs;
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              var t = docs[index].data() as Map<String, dynamic>;
              return ListTile(
                leading: const Icon(Icons.trip_origin),
                title: Text("${t["pickup"]} → ${t["destination"]}"),
                subtitle: Text("الحالة: ${t["status"]}"),
                trailing: Text("${t["price"]} د.ج"),
              );
            },
          );
        },
      ),
    );
  }
}

////////////////////////////////////////////////////////
/// Admin Buses
////////////////////////////////////////////////////////

class AdminBuses extends StatelessWidget {
  const AdminBuses({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("إدارة الحافلات")),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection("buses").snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          var docs = snapshot.data!.docs;
          if (docs.isEmpty) {
            return const Center(child: Text("لا توجد حافلات مسجلة"));
          }
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              var b = docs[index].data() as Map<String, dynamic>;
              return ListTile(
                leading: const Icon(Icons.directions_bus),
                title: Text(b["name"] ?? "حافلة"),
                subtitle: Text("المقاعد: ${b["seats"] ?? 0}"),
              );
            },
          );
        },
      ),
    );
  }
}
