import 'package:flutter/material.dart';

class ProgressStep extends StatelessWidget {
  final String label;
  final double threshold;
  final double progress;
  final Color color;

  const ProgressStep({
    super.key,
    required this.label,
    required this.threshold,
    required this.progress,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    bool done = progress >= threshold;
    return Column(
      children: [
        CircleAvatar(
          radius: 14,
          backgroundColor: done ? color : Colors.grey,
          child: done ? const Icon(Icons.check, size: 16, color: Colors.white) : null,
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    );
  }
}
