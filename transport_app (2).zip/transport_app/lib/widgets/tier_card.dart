import 'package:flutter/material.dart';
import '../models/tier_model.dart';

class TierCard extends StatelessWidget {
  final Tier tier;
  final double distance;
  final VoidCallback onTap;

  const TierCard({
    super.key,
    required this.tier,
    required this.distance,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: tier.color),
        title: Text(tier.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text("${tier.description} • وصول ${tier.eta}"),
        trailing: Text(
          "${(distance * tier.pricePerKm).toStringAsFixed(2)} د.ج",
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        onTap: onTap,
      ),
    );
  }
}
