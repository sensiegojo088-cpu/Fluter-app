import 'package:flutter/material.dart';
import '../core/constants/app_colors.dart';

class SeatWidget extends StatelessWidget {
  final bool isSelected;
  final bool isBooked;

  const SeatWidget({
    super.key,
    required this.isSelected,
    required this.isBooked,
  });

  @override
  Widget build(BuildContext context) {
    Color color;
    if (isBooked) {
      color = AppColors.seatBooked;
    } else if (isSelected) {
      color = AppColors.seatSelected;
    } else {
      color = AppColors.seatAvailable;
    }

    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(8),
      ),
    );
  }
}
