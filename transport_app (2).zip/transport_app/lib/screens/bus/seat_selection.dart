import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../../widgets/seat_widget.dart';

class SeatSelection extends StatefulWidget {
  const SeatSelection({super.key});

  @override
  State<SeatSelection> createState() => _SeatSelectionState();
}

class _SeatSelectionState extends State<SeatSelection> {
  List<int> selectedSeats = [];
  List<int> bookedSeats = [3, 7, 10];

  void toggleSeat(int seat) {
    if (bookedSeats.contains(seat)) return;
    setState(() {
      if (selectedSeats.contains(seat)) {
        selectedSeats.remove(seat);
      } else {
        selectedSeats.add(seat);
      }
    });
  }

  void confirmBooking() {
    String qrData = "TICKET:${selectedSeats.join("-")}";
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("تذكرتك"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("المقاعد: ${selectedSeats.join(", ")}"),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(10),
              color: Colors.white,
              child: QrImageView(data: qrData, size: 200),
            ),
            const SizedBox(height: 10),
            const Text("يرجى إبراز الرمز للسائق"),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("موافق"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("اختيار المقاعد")),
      body: Column(
        children: [
          const SizedBox(height: 10),
          const Text("اختر مقعدك", style: TextStyle(fontSize: 18)),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Row(children: [SeatWidget(isBooked: false, isSelected: false), const SizedBox(width: 4), const Text("متاح")]),
                Row(children: [SeatWidget(isBooked: false, isSelected: true), const SizedBox(width: 4), const Text("مختار")]),
                Row(children: [SeatWidget(isBooked: true, isSelected: false), const SizedBox(width: 4), const Text("محجوز")]),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(10),
              itemCount: 15,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
              ),
              itemBuilder: (context, index) {
                int seat = index + 1;
                return GestureDetector(
                  onTap: () => toggleSeat(seat),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SeatWidget(
                        isBooked: bookedSeats.contains(seat),
                        isSelected: selectedSeats.contains(seat),
                      ),
                      Text("$seat", style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ],
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: selectedSeats.isEmpty ? null : confirmBooking,
                child: const Text("تأكيد الحجز"),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
