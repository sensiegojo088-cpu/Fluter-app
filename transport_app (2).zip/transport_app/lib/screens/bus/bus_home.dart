import 'package:flutter/material.dart';
import 'seat_selection.dart';

class BusHome extends StatelessWidget {
  const BusHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("الحافلات المتاحة")),
      body: ListView.builder(
        itemCount: 3,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.all(10),
            child: ListTile(
              leading: const Icon(Icons.directions_bus),
              title: Text("خط ${index + 1}"),
              subtitle: Text("المقاعد المتاحة: ${10 - index * 2}"),
              trailing: ElevatedButton(
                child: const Text("انضم"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SeatSelection()),
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
