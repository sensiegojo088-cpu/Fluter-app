import 'package:flutter/material.dart';
import '../../core/services/auth_service.dart';
import 'otp_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController phoneController = TextEditingController();
  final AuthService _authService = AuthService();
  bool isLoading = false;

  void sendOTP() async {
    String phone = phoneController.text.trim();

    if (phone.isEmpty) {
      showError("أدخل رقم الهاتف");
      return;
    }

    if (!phone.startsWith("+")) {
      showError("أدخل الرقم بالصيغة الدولية مثال: +213XXXXXXXXX");
      return;
    }

    setState(() => isLoading = true);

    await _authService.sendOTP(
      phoneNumber: phone,
      onCodeSent: (verificationId) {
        setState(() => isLoading = false);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => OTPScreen(verificationId: verificationId),
          ),
        );
      },
      onError: (error) {
        setState(() => isLoading = false);
        showError(error);
      },
    );
  }

  void showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("تسجيل الدخول")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 40),
            const Icon(Icons.phone_android, size: 80),
            const SizedBox(height: 20),
            const Text(
              "أدخل رقم هاتفك",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text("سنرسل لك رمز تحقق", style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 30),
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: "+213XXXXXXXXX",
                prefixIcon: Icon(Icons.phone),
                labelText: "رقم الهاتف",
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: isLoading ? null : sendOTP,
                child: isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text("إرسال رمز التحقق", style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
