import 'package:flutter/material.dart';

class PublicTaxiHome extends StatefulWidget {
  const PublicTaxiHome({super.key});

  @override
  State<PublicTaxiHome> createState() => _PublicTaxiHomeState();
}

class _PublicTaxiHomeState extends State<PublicTaxiHome> {
  final int totalSeats = 4;
  int joinedPassengers = 1;

  void joinTrip() {
    if (joinedPassengers >= totalSeats) return;
    setState(() {
      joinedPassengers++;
    });
    if (joinedPassengers == totalSeats) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("اكتمل عدد الركاب! الرحلة ستبدأ الآن"),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("التاكسي العمومي")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const Text("رحلة متاحة", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    Text("الركاب: $joinedPassengers / $totalSeats"),
                    const SizedBox(height: 10),
                    LinearProgressIndicator(
                      value: joinedPassengers / totalSeats,
                      color: joinedPassengers == totalSeats ? Colors.green : Colors.blue,
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: List.generate(totalSeats, (index) {
                        return Icon(
                          Icons.person,
                          size: 40,
                          color: index < joinedPassengers ? Colors.green : Colors.grey,
                        );
                      }),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: joinedPassengers < totalSeats ? joinTrip : null,
                child: Text(joinedPassengers < totalSeats ? "انضم إلى الرحلة" : "الرحلة مكتملة"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
