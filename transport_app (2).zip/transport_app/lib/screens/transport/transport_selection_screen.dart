import 'package:flutter/material.dart';
import '../bus/bus_home.dart';
import '../public_taxi/public_taxi_home.dart';
import '../private_taxi/map_screen.dart';

class TransportSelectionScreen extends StatelessWidget {
  const TransportSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("اختر وسيلة النقل")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Text("🚍", style: TextStyle(fontSize: 20)),
                label: const Text("الحافلة"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const BusHome()),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Text("🚕", style: TextStyle(fontSize: 20)),
                label: const Text("التاكسي العمومي"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const PublicTaxiHome()),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Text("🚘", style: TextStyle(fontSize: 20)),
                label: const Text("التاكسي الخاص"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const MapScreen()),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
