import 'package:flutter/material.dart';
import '../../models/tier_model.dart';
import '../../models/trip_model.dart';
import '../../widgets/tier_card.dart';
import 'confirm_trip.dart';

class TierSelection extends StatelessWidget {
  final double distance;
  final String pickup;
  final String destination;

  const TierSelection({
    super.key,
    required this.distance,
    required this.pickup,
    required this.destination,
  });

  final List<Tier> tiers = const [
    Tier(
      id: "economy",
      name: "اقتصادي",
      color: Colors.blue,
      pricePerKm: 0.5,
      description: "سيارة اقتصادية",
      eta: "5 دقائق",
    ),
    Tier(
      id: "comfort",
      name: "متوسط",
      color: Colors.orange,
      pricePerKm: 0.8,
      description: "سيارة مريحة",
      eta: "4 دقائق",
    ),
    Tier(
      id: "luxury",
      name: "فاخر",
      color: Colors.purple,
      pricePerKm: 1.2,
      description: "سيارة فاخرة",
      eta: "3 دقائق",
    ),
  ];

  void selectTier(BuildContext context, Tier tier) {
    Trip trip = Trip(
      id: "",
      tier: tier,
      distance: distance,
      duration: (distance * 3).round(),
      price: distance * tier.pricePerKm,
      pickup: pickup,
      destination: destination,
      status: "pending",
    );

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ConfirmTrip(trip: trip)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("اختر درجة الخدمة")),
      body: ListView.builder(
        itemCount: tiers.length,
        itemBuilder: (context, index) {
          Tier tier = tiers[index];
          return TierCard(
            tier: tier,
            distance: distance,
            onTap: () => selectTier(context, tier),
          );
        },
      ),
    );
  }
}
