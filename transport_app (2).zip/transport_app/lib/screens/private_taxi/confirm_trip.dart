import 'package:flutter/material.dart';
import '../../models/trip_model.dart';
import '../../core/services/firebase_service.dart';
import 'trip_tracking.dart';

class ConfirmTrip extends StatelessWidget {
  final Trip trip;

  const ConfirmTrip({super.key, required this.trip});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("تأكيد الرحلة")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("من: ${trip.pickup}"),
                    const Divider(),
                    Text("إلى: ${trip.destination}"),
                    const Divider(),
                    Text("المسافة: ${trip.distance.toStringAsFixed(2)} كم"),
                    Text("المدة: ${trip.duration} دقيقة"),
                    const Divider(),
                    Row(
                      children: [
                        CircleAvatar(backgroundColor: trip.tier.color, radius: 8),
                        const SizedBox(width: 8),
                        Text("${trip.tier.name} - ${trip.tier.eta}"),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("السعر التقريبي", style: TextStyle(fontSize: 16)),
                  Text(
                    "${trip.price.toStringAsFixed(2)} د.ج",
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.green),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  FirebaseService db = FirebaseService();
                  String tripId = await db.createTrip(trip);
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (_) => TripTracking(trip: trip, tripId: tripId),
                    ),
                  );
                },
                child: const Text("طلب الرحلة"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
