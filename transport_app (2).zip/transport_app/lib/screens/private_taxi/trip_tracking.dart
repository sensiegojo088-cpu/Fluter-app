import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/trip_model.dart';
import '../../core/services/firebase_service.dart';
import '../../utils/notification_helper.dart';
import '../../widgets/progress_step.dart';

class TripTracking extends StatefulWidget {
  final Trip trip;
  final String tripId;

  const TripTracking({
    super.key,
    required this.trip,
    required this.tripId,
  });

  @override
  State<TripTracking> createState() => _TripTrackingState();
}

class _TripTrackingState extends State<TripTracking> {
  double progress = 0;
  final FirebaseService _db = FirebaseService();

  @override
  void initState() {
    super.initState();
    simulateTrip();
  }

  void simulateTrip() async {
    final steps = [
      {"status": "started", "progress": 0.25},
      {"status": "on_the_way", "progress": 0.50},
      {"status": "approaching", "progress": 0.75},
      {"status": "arrived", "progress": 1.0},
    ];

    for (var step in steps) {
      await Future.delayed(const Duration(seconds: 3));
      await _db.updateStatus(widget.tripId, step["status"] as String);
      setState(() {
        progress = step["progress"] as double;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("متابعة الرحلة")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Real-time status from Firestore
            StreamBuilder<DocumentSnapshot>(
              stream: _db.streamTrip(widget.tripId),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const SizedBox();
                String status = snapshot.data!["status"] ?? "";

                if (status == "driver_assigned") {
                  NotificationHelper.driverAccepted(context);
                }

                return Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text("الحالة: $status", style: const TextStyle(fontSize: 16)),
                );
              },
            ),

            const SizedBox(height: 20),

            LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              color: widget.trip.tier.color,
            ),

            const SizedBox(height: 30),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ProgressStep(label: "بداية", threshold: 0.25, progress: progress, color: widget.trip.tier.color),
                ProgressStep(label: "في الطريق", threshold: 0.50, progress: progress, color: widget.trip.tier.color),
                ProgressStep(label: "اقتراب", threshold: 0.75, progress: progress, color: widget.trip.tier.color),
                ProgressStep(label: "وصول", threshold: 1.0, progress: progress, color: widget.trip.tier.color),
              ],
            ),

            const SizedBox(height: 40),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text("من: ${widget.trip.pickup}"),
                    const Divider(),
                    Text("إلى: ${widget.trip.destination}"),
                    const Divider(),
                    Text(
                      "السعر: ${widget.trip.price.toStringAsFixed(2)} د.ج",
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),

            const Spacer(),

            if (progress >= 1.0)
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    await _db.completeTrip(widget.tripId);
                    Navigator.popUntil(context, NamedRoutes.isFirst);
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  child: const Text("إنهاء الرحلة"),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class NamedRoutes {
  static bool isFirst(Route<dynamic> route) => route.isFirst;
}
