import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../../utils/distance_calculator.dart';
import 'tier_selection.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? mapController;
  LatLng currentLocation = const LatLng(36.1911, 5.4137);
  LatLng? destination;
  Set<Marker> markers = {};
  double distance = 0;

  @override
  void initState() {
    super.initState();
    getLocation();
  }

  Future<void> getLocation() async {
    LocationPermission permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) return;

    Position position = await Geolocator.getCurrentPosition();

    setState(() {
      currentLocation = LatLng(position.latitude, position.longitude);
      markers.add(
        Marker(
          markerId: const MarkerId("pickup"),
          position: currentLocation,
          infoWindow: const InfoWindow(title: "موقعك"),
        ),
      );
    });
  }

  void setDestination(LatLng pos) {
    setState(() {
      destination = pos;
      markers.removeWhere((m) => m.markerId.value == "destination");
      markers.add(
        Marker(
          markerId: const MarkerId("destination"),
          position: pos,
          infoWindow: const InfoWindow(title: "الوجهة"),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        ),
      );
      distance = calculateDistance(
        currentLocation.latitude,
        currentLocation.longitude,
        pos.latitude,
        pos.longitude,
      );
    });

    if (distance <= 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("تبقى أقل من 10 كم للوصول")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("الخريطة")),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: currentLocation,
              zoom: 14,
            ),
            markers: markers,
            myLocationEnabled: true,
            onMapCreated: (controller) {
              mapController = controller;
            },
            onTap: (pos) {
              setDestination(pos);
            },
          ),
          Positioned(
            bottom: 20,
            left: 20,
            right: 20,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "المسافة: ${distance.toStringAsFixed(2)} كم",
                    style: const TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: destination == null
                          ? null
                          : () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => TierSelection(
                                    distance: distance,
                                    pickup: "الموقع الحالي",
                                    destination: "الوجهة",
                                  ),
                                ),
                              );
                            },
                      child: const Text("متابعة الحجز"),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
