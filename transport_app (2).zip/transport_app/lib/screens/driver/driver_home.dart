import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../../core/services/firebase_service.dart';
import '../../core/services/location_service.dart';

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});

  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  final FirebaseService _db = FirebaseService();
  final LocationService _location = LocationService();
  bool isScanning = false;
  bool locked = false;

  static const String driverId = "driver123";

  @override
  void initState() {
    super.initState();
    _location.updateDriverLocation(driverId);
  }

  void acceptTrip(String tripId) async {
    await _db.acceptTrip(tripId, driverId);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("تم قبول الرحلة"), backgroundColor: Colors.green),
    );
  }

  void handleQR(String code) async {
    if (locked) return;
    locked = true;

    bool isValid = code.startsWith("TICKET:");

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(isValid ? "✅ مقبول" : "❌ مرفوض"),
        backgroundColor: isValid ? Colors.green : Colors.red,
      ),
    );

    await Future.delayed(const Duration(seconds: 2));
    locked = false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("واجهة السائق")),
      body: isScanning
          ? Column(
              children: [
                Expanded(
                  child: MobileScanner(
                    onDetect: (capture) {
                      final code = capture.barcodes.first.rawValue;
                      if (code != null) handleQR(code);
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: ElevatedButton(
                    onPressed: () => setState(() => isScanning = false),
                    child: const Text("إيقاف المسح"),
                  ),
                ),
              ],
            )
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.qr_code_scanner),
                      label: const Text("بدء فحص التذاكر"),
                      onPressed: () => setState(() => isScanning = true),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text("رحلات اليوم", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  const Card(
                    child: ListTile(
                      leading: Icon(Icons.trip_origin),
                      title: Text("رحلة قيد الانتظار"),
                      subtitle: Text("المسافة: 8 كم"),
                      trailing: Text("4.50 د.ج"),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
