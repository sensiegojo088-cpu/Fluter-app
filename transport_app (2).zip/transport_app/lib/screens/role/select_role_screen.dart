import 'package:flutter/material.dart';
import '../driver/driver_home.dart';

class SelectRoleScreen extends StatelessWidget {
  const SelectRoleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("اختر نوع المستخدم")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 200,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.person),
                label: const Text("راكب"),
                onPressed: () {
                  Navigator.pushReplacementNamed(context, "/transport");
                },
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: 200,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.drive_eta),
                label: const Text("سائق"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const DriverHome()),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
