package com.transport.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
