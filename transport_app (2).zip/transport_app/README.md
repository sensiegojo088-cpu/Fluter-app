# Transport App - منصة النقل المتكاملة

تطبيق Flutter يجمع ثلاثة أنظمة نقل: الحافلة، التاكسي العمومي، والتاكسي الخاص.

---

## 🚀 خطوات التشغيل

### 1. إعداد Firebase
- أنشئ مشروعاً على [Firebase Console](https://console.firebase.google.com)
- فعّل: Firestore، Authentication، Messaging
- حمّل `google-services.json` وضعه في `android/app/`

### 2. إعداد Google Maps
- احصل على API Key من [Google Cloud Console](https://console.cloud.google.com)
- ضعه في `android/app/src/main/AndroidManifest.xml`:
```xml
<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="YOUR_GOOGLE_MAPS_API_KEY"/>
```

### 3. تشغيل المشروع
```bash
flutter clean
flutter pub get
flutter run
```

### 4. بناء APK
```bash
flutter build apk --release
```
الملف الناتج: `build/app/outputs/flutter-apk/app-release.apk`

### 5. بناء App Bundle
```bash
flutter build appbundle
```

---

## 📁 هيكل المشروع

```
lib/
├── main.dart
├── core/
│   ├── constants/app_colors.dart
│   └── services/
│       ├── firebase_service.dart
│       ├── location_service.dart
│       └── driver_match_service.dart
├── models/
│   ├── user_model.dart
│   ├── trip_model.dart
│   ├── tier_model.dart
│   ├── driver_model.dart
│   └── rating_model.dart
├── screens/
│   ├── splash/
│   ├── auth/
│   ├── role/
│   ├── transport/
│   ├── bus/
│   ├── public_taxi/
│   ├── private_taxi/
│   └── driver/
├── admin/
├── widgets/
└── utils/
```

---

## 🗄️ هيكل Firestore

```
users/{userId}        → name, role, phone
drivers/{driverId}    → name, car, rating, lat, lng, available
buses/{busId}         → name, seats, route
routes/{routeId}      → stops, schedule
trips/{tripId}        → pickup, destination, distance, price, driverId, status
ratings/{ratingId}    → tripId, driverId, stars, comment
notifications/{id}    → userId, message, read
```

---

## ⚙️ Dependencies

```yaml
firebase_core: ^2.24.0
cloud_firestore: ^4.13.0
firebase_auth: ^4.15.0
firebase_messaging: ^14.7.0
google_maps_flutter: ^2.5.0
geolocator: ^10.1.0
qr_flutter: ^4.1.0
mobile_scanner: ^3.5.0
```

---

## ⚠️ ملاحظات مهمة

- استبدل `google-services.json` بملفك الحقيقي
- استبدل `YOUR_GOOGLE_MAPS_API_KEY` بمفتاحك الحقيقي
- `driverId` في `driver_home.dart` مؤقت، اربطه بـ Firebase Auth لاحقاً
